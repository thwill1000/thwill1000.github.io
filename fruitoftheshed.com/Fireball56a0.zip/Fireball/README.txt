Fireball by Anthony Clarke

After loading fireball.bas go into mode 1 or mode 4 before running or you'll get an "OUT OF MEMORY" 
error.

Good luck :) 