This is a version of the Space Invaders game for the 
Maximite.  It was written by Fabrice Muller (France).

To play, unzip all the files into a directory on your SD
card, change into the directory and then run the file 
INVADERS.BAS.

Space Bar   = The fire button
Left Arrow  = Move your gun to the left
Right Arrow = Move your gun to the right
CTRL-C      = Quit

This must be run using MMBasic 3.0A as it relies on some 
advanced features of this version to control the invaders.

It looks best if played on a composite PAL monitor but it
will also run fine on a VGA monitor.
