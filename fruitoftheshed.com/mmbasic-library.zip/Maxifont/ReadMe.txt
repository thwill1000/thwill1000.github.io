Maxifont.bas

Maxifont is a small program written by Dennis Wyatt for the Maximite Computer by Geoff Graham 2011/2012

It will create a font, based on your input..

It will save the font to a filename of your choice, appended with the .fnt descriptor..

It can add , flip horizontally or vertically, any of the characters it creates.

You only have to run the MAxifont.bas program and it will check the current Version of mmBAsic and run the appropriate program for the version Installed.

Currently only version 2.7B, 3, 3.0A and 3.1 are supported..

The limitations of the software is, that there is only a limited memory size, for variables and arrays, and therfore, only small font sizes can have lots of characters. The larger the font size, the less characters can be edited. This lies in the way Arrays are stored and in part , the way I have written Maxifont.

I will endeavour to Update the program so that it could enable larger fonts, with support for more characters

Regards

Dennis Wyatt

dpwyatt@iinet.net.au