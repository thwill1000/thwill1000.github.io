Colour Maximite V4.0 Demos from Fabrice Muller, France

Arcade:   Arcade game where you have to shoot enemies until you die 3 times.
	  It shows how to use multi-sprite enemies, audio modules as sound effects and 
	  ADC input for moving your ship Right/Left with a potentiometer + a Button to fire.

Breakout: Probably the easiest game to program if you start with Maximite.
	  Use a potentiometer connected to the Maximite ADC input to move your racket.
	  It shows how to use BMP, files, Sprites and Array.

Lander:   Well, here we go back to 1969 and try to Land on the Moon.
	  Take care of your fuel or you will crash :)
	  You will see how to make a random moon surface, use music module
	  as audio effects, sprites and buttons to be able to land you ship.

Sprites3: It was one of my first tests of Sprites and Blitter at same time and
	  music modules for the background music.
	  Here it's nothing to do.
	  Just look at the source to learn how to use everything together.

Don't forget to copy the *.mod files to "a:" before starting the demos that need them.

Arcade and Breakout .BAS files contain hardware connections in comments.
